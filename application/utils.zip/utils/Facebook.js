export default {
	config: {
		application_id: '532785920254078',
		permissions: ['public_profile', 'email']
	}
};