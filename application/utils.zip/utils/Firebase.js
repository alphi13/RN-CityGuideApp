
//////////////////// FIREBASE

export default firebaseConfig = {
    apiKey: "AIzaSyATUJnO6qLdnqORAMRgE_clWH7Tqkw2MFw",
    authDomain: "alqassim.x10.ltd",
    databaseURL: "http://alqassim.x10.ltd",
    projectId: "alqassim-9c853",
    storageBucket: "",
  };