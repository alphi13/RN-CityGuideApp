
//////////////////// COLORS APP

const ColorsApp = {

    PRIMARY: "#fd5c63",
    SECOND: "#fd5c63",
    TERTIARY: "#707a7f",

};

export default ColorsApp;
